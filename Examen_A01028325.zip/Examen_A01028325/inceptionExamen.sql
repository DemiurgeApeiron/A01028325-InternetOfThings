use Biblioteca;
SET SQL_SAFE_UPDATES = 0;
DELETE FROM libros_autores;
DELETE FROM libros_tags;
DELETE FROM Autores;
DELETE FROM Tags;
DELETE FROM Libros;


